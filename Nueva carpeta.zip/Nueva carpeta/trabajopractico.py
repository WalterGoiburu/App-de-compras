import flet as ft 

def main(page: ft.Page):
    page.window_width = 600
    page.window_height = 200
    page.bgcolor = ft.colors.LIGHT_GREEN
    
    page.title = "¡Mis Compras!"

    # Crear un campo de texto para la entrada
    new_task = ft.TextField(hint_text="Ingrese el artículo que desea comprar", width=400)
    tasks_column = ft.Column()  # Columna para almacenar las tareas

    def add_clicked(e):
        if new_task.value:  # Asegúrate de que no esté vacío
            task_row = ft.Row([
                ft.Checkbox(label=new_task.value),
                ft.ElevatedButton("Modificar", on_click=lambda e, task_label=new_task.value: edit_task(task_label), bgcolor=ft.colors.YELLOW),
                ft.ElevatedButton("Eliminar", on_click=lambda e, task_label=new_task.value: delete_task(task_label), bgcolor=ft.colors.RED)
            ], alignment="spaceBetween")
            tasks_column.controls.append(task_row)  # Agregar la tarea a la columna
            page.add(tasks_column)  # Agregar la columna a la página
            new_task.value = ""  # Limpiar el campo de entrada
            new_task.focus()  # Focalizar el campo de entrada
            new_task.update()  # Actualizar el campo

            # Actualizar la vista
            page.update()

    def delete_task(task_label):
        # Eliminar la tarea de la columna
        for task in tasks_column.controls:
            if task.controls[0].label == task_label:
                tasks_column.controls.remove(task)
                break
        page.update()  # Actualizar la interfaz

    def edit_task(task_label):
        # Modificar la tarea
        for task in tasks_column.controls:
            if task.controls[0].label == task_label:
                new_task.value = task.controls[0].label  # Cargar el texto en el campo de entrada
                delete_task(task_label)  # Eliminar la tarea original
                break

    # Logo y texto del encabezado
    logo_path = "C:/Users/walte/OneDrive/Imágenes/Saved Pictures/code.JFIF"
    
    # Verifica que la imagen existe antes de cargarla
    try:
        logo = ft.Image(src=logo_path, width=600, height=400)
    except Exception as e:
        print(f"Error al cargar la imagen: {e}")
        logo = ft.Text("Logo no disponible", color=ft.colors.RED)

    header_text = ft.Text("¡Bienvenido a la App de Compras! Disfruta haciendo tu lista y nunca olvides tus artículos favoritos.", size=24, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE)

    # Organizar el encabezado en una columna
    header = ft.Column([
        logo,
        header_text
    ], alignment="center")

    # Agregar elementos a la aplicación
    page.add(
        header,
        ft.Divider(height=20),  # Agrega un divisor
        ft.Row([new_task, ft.ElevatedButton("Agregar", on_click=add_clicked, bgcolor=ft.colors.WHITE)])
    )

    # Agregar la columna de tareas a la página
    page.add(tasks_column)

    # Estilo de la página
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.padding = 20  # Espaciado en la página

# Ejecutar la aplicación
ft.app(target=main)




