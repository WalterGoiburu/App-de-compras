import flet as ft

def main(page: ft.Page):
    page.window_width = 600
    page.window_height = 400
    page.title = "Lista de Compras para Clientes"

    # Crear un campo de texto para la entrada de compra
    purchase_input = ft.TextField(hint_text="Ingrese el artículo que desea comprar", width=400)

    # Botón para agregar el artículo
    def add_item(e):
        if purchase_input.value:  # Asegúrate de que no esté vacío
            page.add(ft.Text(f"Artículo agregado: {purchase_input.value}", size=16))
            purchase_input.value = ""  # Limpiar el campo de entrada
            purchase_input.focus()  # Focalizar el campo de entrada
            purchase_input.update()  # Actualizar el campo

    # Botón para agregar el artículo
    add_button = ft.ElevatedButton("Agregar Artículo", on_click=add_item)

    # Agregar elementos a la aplicación
    page.add(
        ft.Column([
            purchase_input,
            add_button
        ], alignment="center", spacing=20)  # Alinear el campo y el botón
    )

# Ejecutar la aplicación
ft.app(target=main)
